from tkinter import *
from tkinter import ttk
import mysql.connector
from tkinter import messagebox
import tkinter
import datetime

#=============================================================main code=========================================================================================
class libraryManagementSystem:
    def __init__(self,root):
        self.root=root
        self.root.title("Library Management System")
        self.root.geometry("1550x800+0+0")
        
        #=======================================================variables=============================================================================
        self.member_var=StringVar()
        self.rollno_var=StringVar()
        self.firstname_var=StringVar()
        self.lastname_var=StringVar()
        self.branch_var=StringVar()
        self.yearofgraduation_var=StringVar()
        self.phoneno_var=StringVar()
        self.address_var=StringVar()
        self.bookid_var=StringVar()
        self.bookname_var=StringVar()
        self.auther_var=StringVar()
        self.dateborrowed_var=StringVar()
        self.datedue_var=StringVar()
        self.daysonbook_var=StringVar()
        self.latereturnfine_var=StringVar()
        self.actualprice_var=StringVar()
        
        lbltitle=Label(self.root,text="LIBRARY MANAGEMENT SYSTEM",bg="powder blue",fg="green",bd=20,relief=RIDGE,font=("times new roman",50,"bold"),padx=2,pady=6)
        lbltitle.pack(side=TOP,fill=X)
        
        frame=Frame(self.root,bd=12,relief=RIDGE,padx=20,bg="light green")
        frame.place(x=0,y=130,width=1530,height=370)
        
        
        #====================================================Dataframeleft====================================================================
        DataFrameLeft=LabelFrame(frame,text="Library Memebership Information",bg="light green",fg="blue",bd=12,font=("times new roman",12,"bold"))
        DataFrameLeft.place(x=0,y=5,width=860,height=320)
        
        lblMember=Label(DataFrameLeft,bg="light green",text="Member Type:",font=("title new roman",12,"bold"),padx=2,pady=6)
        lblMember.grid(row=0,column=0,sticky=W)
        
        comMember=ttk.Combobox(DataFrameLeft,textvariable=self.member_var,font=("times new roman",15,"bold"),width=24,state="readonly")
        comMember["value"]=("Admin staff","student","lecturer")
        comMember.grid(row=0,column=1)      
        
        lblRollno=Label(DataFrameLeft,bg="light green",text="Roll no:",font=("arial",12,"bold"),padx=2,pady=6)
        lblRollno.grid(row=1,column=0,sticky=W)
        txtRollno=Entry(DataFrameLeft,font=("arial",13,"bold"),textvariable=self.rollno_var,width=29)
        txtRollno.grid(row=1,column=1)
        
        lblFirstName=Label(DataFrameLeft,bg="light green",text="First Name:",font=("arial",12,"bold"),padx=2,pady=6)
        lblFirstName.grid(row=2,column=0,sticky=W)
        txtFirstName=Entry(DataFrameLeft,font=("arial",13,"bold"),textvariable=self.firstname_var,width=29)
        txtFirstName.grid(row=2,column=1)
        
        lblLastName=Label(DataFrameLeft,bg="light green",text="Last Name:",font=("arial",12,"bold"),padx=2,pady=6)
        lblLastName.grid(row=3,column=0,sticky=W)
        txtLastName=Entry(DataFrameLeft,font=("arial",13,"bold"),textvariable=self.lastname_var,width=29)
        txtLastName.grid(row=3,column=1)
        
        lblBranch=Label(DataFrameLeft,bg="light green",text="Branch:",font=("arial",12,"bold"),padx=2,pady=6)
        lblBranch.grid(row=4,column=0,sticky=W)
        txtBranch=Entry(DataFrameLeft,font=("arial",13,"bold"),textvariable=self.branch_var,width=29)
        txtBranch.grid(row=4,column=1)
        
        lblYear=Label(DataFrameLeft,bg="light green",text="Graduation year:",font=("arial",12,"bold"),padx=2,pady=6)
        lblYear.grid(row=5,column=0,sticky=W)
        txtYear=Entry(DataFrameLeft,font=("arial",13,"bold"),textvariable=self.yearofgraduation_var,width=29)
        txtYear.grid(row=5,column=1)
        
        lblPhoneno=Label(DataFrameLeft,bg="light green",text="Phone Number:",font=("arial",12,"bold"),padx=2,pady=6)
        lblPhoneno.grid(row=6,column=0,sticky=W)
        txtPhoneno=Entry(DataFrameLeft,font=("arial",13,"bold"),textvariable=self.phoneno_var,width=29)
        txtPhoneno.grid(row=6,column=1)
        
        lblAddress=Label(DataFrameLeft,bg="light green",text="Address:",font=("arial",12,"bold"),padx=2,pady=6)
        lblAddress.grid(row=7,column=0,sticky=W)
        txtAddress=Entry(DataFrameLeft,font=("arial",13,"bold"),textvariable=self.address_var,width=29)
        txtAddress.grid(row=7,column=1)
        
        lblBookid=Label(DataFrameLeft,bg="light green",text="Book id:",font=("arial",12,"bold"),padx=2,pady=6)
        lblBookid.grid(row=0,column=2,sticky=W)
        txtBookid=Entry(DataFrameLeft,font=("arial",13,"bold"),textvariable=self.bookid_var,width=29)
        txtBookid.grid(row=0,column=3)
        
        lblBookName=Label(DataFrameLeft,bg="light green",text="Book Name:",font=("arial",12,"bold"),padx=2,pady=6)
        lblBookName.grid(row=1,column=2,sticky=W)
        txtBookName=Entry(DataFrameLeft,font=("arial",13,"bold"),textvariable=self.bookname_var,width=29)
        txtBookName.grid(row=1,column=3)
        
        lblAuther=Label(DataFrameLeft,bg="light green",text="Auther:",font=("arial",12,"bold"),padx=2,pady=6)
        lblAuther.grid(row=2,column=2,sticky=W)
        txtAuther=Entry(DataFrameLeft,font=("arial",13,"bold"),textvariable=self.auther_var,width=29)
        txtAuther.grid(row=2,column=3)
        
        lblDateBorrowed=Label(DataFrameLeft,bg="light green",text="Date Borrowed:",font=("arial",12,"bold"),padx=2,pady=6)
        lblDateBorrowed.grid(row=3,column=2,sticky=W)
        txtDateBorrowed=Entry(DataFrameLeft,font=("arial",13,"bold"),textvariable=self.dateborrowed_var,width=29)
        txtDateBorrowed.grid(row=3,column=3)
        
        lblDateDue=Label(DataFrameLeft,bg="light green",text="Date Due",font=("arial",12,"bold"),padx=2,pady=6)
        lblDateDue.grid(row=4,column=2,sticky=W)
        txtDateDue=Entry(DataFrameLeft,font=("arial",13,"bold"),textvariable=self.datedue_var,width=29)
        txtDateDue.grid(row=4,column=3)
        
        lblDaysOnBook=Label(DataFrameLeft,bg="light green",text="Days On Book",font=("arial",12,"bold"),padx=2,pady=6)
        lblDaysOnBook.grid(row=5,column=2,sticky=W)
        txtDaysOnBook=Entry(DataFrameLeft,font=("arial",13,"bold"),textvariable=self.daysonbook_var,width=29)
        txtDaysOnBook.grid(row=5,column=3)
        
        lblLateReturnFine=Label(DataFrameLeft,bg="light green",text="Late Return Fine:",font=("arial",12,"bold"),padx=2,pady=6)
        lblLateReturnFine.grid(row=6,column=2,sticky=W)
        txtLateReturnFine=Entry(DataFrameLeft,font=("arial",13,"bold"),textvariable=self.latereturnfine_var,width=29)
        txtLateReturnFine.grid(row=6,column=3)
        
        lblActualPrice=Label(DataFrameLeft,bg="light green",text="Acutal Price:",font=("arial",12,"bold"),padx=2,pady=6)
        lblActualPrice.grid(row=7,column=2,sticky=W)
        txtActualPrice=Entry(DataFrameLeft,font=("arial",13,"bold"),textvariable=self.actualprice_var,width=29)
        txtActualPrice.grid(row=7,column=3) 
      
        #====================================================DataframeRight====================================================================
          
        DataFrameRight=LabelFrame(frame,text="Book Details",bg="light green",fg="blue",bd=12,relief=RIDGE,font=("times new roman",12,"bold"))
        DataFrameRight.place(x=910,y=5,width=540,height=320)  
        
        
        self.txtBox=Text(DataFrameRight,font=("arial",12,"bold"),width=32,height=14,padx=2,pady=6)
        self.txtBox.grid(row=0,column=2)
        
        listScrollbar=Scrollbar(DataFrameRight)
        listScrollbar.grid(row=0,column=1,sticky="ns")
        
        listBooks=['The Great Gatsby','Jane Eyre','To Kill a Mockingbird','The Catcher in the Rye','Mrs Dalloway','Wuthering Heights','Ulysses','Beloved',
                  'Adventures of Huckleberry Finn','One Hundred Years of Solitude','A Passage to India','Things Fall Apart','David Copperfield','Invisible Man',
                  'Little Women','The Sun Also Rises','The grapes of warth','lolita','Catch-22','Middlemarch','Brave New World','Vanity Fair','Lord of the flies',
                  'Madame Bovary','As I lay Dying','The good solider','Midnight children']
        
        def SelectBook(event=""):
            value=str(listBox.get(listBox.curselection))
            x=value
            if(x=="The Great Gatsby"):
                self.bookid_var.set("123")
                self.bookname_var.set("The Great Gatsby")
                self.auther_var.set("F.Scott Fitzgerald")
                d1=datetime.datetime.today()
                d2=datetime.timedelta(days=21)
                d3=d1+d2
                self.dateborrowed_var.set(d1)
                self.datedue_var.set(d3)
                self.daysonbook_var.set(21)
                self.latereturnfine_var.set("Rs.15")
                self.actualprice_var.set("Rs.500")
        
            elif(x=="Jane Eyre"):
                self.bookid_var.set("456")
                self.bookname_var.set("Jane Eyre")
                self.auther_var.set("Charlotte Bronte")
                
                d1=datetime.datetime.today()
                d2=datetime.timedelta(days=21)
                d3=d1+d2
                self.dateborrowed_var.set(d1)
                self.datedue_var.set(d3)
                self.daysonbook_var.set(21)
                self.latereturnfine_var.set("Rs.15")
                self.actualprice_var.set("Rs.754")
                
            elif(x=="To Kill a Mockingbird"):
                self.bookid_var.set("789")
                self.bookname_var.set("To Kill a Mockingbird")
                self.auther_var.set("Harper Lee")
                
                d1=datetime.datetime.today()
                d2=datetime.timedelta(days=21)
                d3=d1+d2
                self.dateborrowed_var.set(d1)
                self.datedue_var.set(d3)
                self.daysonbook_var.set(21)
                self.latereturnfine_var.set("Rs.15")
                self.actualprice_var.set("Rs.643")
                
            elif(x=="The Catcher in the Rye"):
                self.bookid_var.set("321")
                self.bookname_var.set("The Catcher in the Rye")
                self.auther_var.set("J.D Salinger")
                
                d1=datetime.datetime.today()
                d2=datetime.timedelta(days=21)
                d3=d1+d2
                self.dateborrowed_var.set(d1)
                self.datedue_var.set(d3)
                self.daysonbook_var.set(21)
                self.latereturnfine_var.set("Rs.15")
                self.actualprice_var.set("Rs.478")
                
            elif(x=="Mrs Dalloway"):
                self.bookid_var.set("432")
                self.bookname_var.set("Mrs Dalloway")
                self.auther_var.set("Virginia Woolf")
                
                d1=datetime.datetime.today()
                d2=datetime.timedelta(days=21)
                d3=d1+d2
                self.dateborrowed_var.set(d1)
                self.datedue_var.set(d3)
                self.daysonbook_var.set(21)
                self.latereturnfine_var.set("Rs.15")
                self.actualprice_var.set("Rs.876")
                
            elif(x=="Wuthering Heights"):
                self.bookid_var.set("543")
                self.bookname_var.set("Wuthering Heights")
                self.auther_var.set("")
                
                d1=datetime.datetime.today()
                d2=datetime.timedelta(days=21)
                d3=d1+d2
                self.dateborrowed_var.set(d1)
                self.datedue_var.set(d3)
                self.daysonbook_var.set(21)
                self.latereturnfine_var.set("Rs.15")
                self.actualprice_var.set("Rs.765")
                
            elif(x=="Ulysses"):
                self.bookid_var.set("654")
                self.bookname_var.set("Ulysses")
                self.auther_var.set("James Joyce")
                
                d1=datetime.datetime.today()
                d2=datetime.timedelta(days=21)
                d3=d1+d2
                self.dateborrowed_var.set(d1)
                self.datedue_var.set(d3)
                self.daysonbook_var.set(21)
                self.latereturnfine_var.set("Rs.15")
                self.actualprice_var.set("Rs.760")
                
            elif(x=="Beloved"):
                self.bookid_var.set("765")
                self.bookname_var.set("Beloved")
                self.auther_var.set("Toni Morrison")
                
                d1=datetime.datetime.today()
                d2=datetime.timedelta(days=21)
                d3=d1+d2
                self.dateborrowed_var.set(d1)
                self.datedue_var.set(d3)
                self.daysonbook_var.set(21)
                self.latereturnfine_var.set("Rs.15")
                self.actualprice_var.set("Rs.654")
                
            elif(x=="Adventures of Huckleberry Finn"):
                self.bookid_var.set("876")
                self.bookname_var.set("Adventures of Huckleberry Finn")
                self.auther_var.set("Mark Twain")
                
                d1=datetime.datetime.today()
                d2=datetime.timedelta(days=21)
                d3=d1+d2
                self.dateborrowed_var.set(d1)
                self.datedue_var.set(d3)
                self.daysonbook_var.set(21)
                self.latereturnfine_var.set("Rs.15")
                self.actualprice_var.set("Rs.765")
                
            elif(x=="One Hundred Years of Solitude"):
                self.bookid_var.set("987")
                self.bookname_var.set("One Hundred Years of Solitude")
                self.auther_var.set("Gabrial Garcia Marquez")
                
                d1=datetime.datetime.today()
                d2=datetime.timedelta(days=21)
                d3=d1+d2
                self.dateborrowed_var.set(d1)
                self.datedue_var.set(d3)
                self.daysonbook_var.set(21)
                self.latereturnfine_var.set("Rs.15")
                self.actualprice_var.set("Rs.734")
                
            elif(x=="A Passage to India"):
                self.bookid_var.set("586")
                self.bookname_var.set("A Passage to India")
                self.auther_var.set("E.M Forster")
                
                d1=datetime.datetime.today()
                d2=datetime.timedelta(days=21)
                d3=d1+d2
                self.dateborrowed_var.set(d1)
                self.datedue_var.set(d3)
                self.daysonbook_var.set(21)
                self.latereturnfine_var.set("Rs.15")
                self.actualprice_var.set("Rs.347")
                
            elif(x=="Things Fall Apart"):
                self.bookid_var.set("965")
                self.bookname_var.set("Things Fall Apart")
                self.auther_var.set("Chinua Achebe")
                
                d1=datetime.datetime.today()
                d2=datetime.timedelta(days=21)
                d3=d1+d2
                self.dateborrowed_var.set(d1)
                self.datedue_var.set(d3)
                self.daysonbook_var.set(21)
                self.latereturnfine_var.set("Rs.15")
                self.actualprice_var.set("Rs.437")
                
            elif(x=="David Copperfield"):
                self.bookid_var.set("386")
                self.bookname_var.set("David Copperfield")
                self.auther_var.set("Charles Dickens")
                
                d1=datetime.datetime.today()
                d2=datetime.timedelta(days=21)
                d3=d1+d2
                self.dateborrowed_var.set(d1)
                self.datedue_var.set(d3)
                self.daysonbook_var.set(21)
                self.latereturnfine_var.set("Rs.15")
                self.actualprice_var.set("Rs.658")
                
            elif(x=="Invisible Man"):
                self.bookid_var.set("396")
                self.bookname_var.set("Invisible Man")
                self.auther_var.set("Ralph Ellison")
                
                d1=datetime.datetime.today()
                d2=datetime.timedelta(days=21)
                d3=d1+d2
                self.dateborrowed_var.set(d1)
                self.datedue_var.set(d3)
                self.daysonbook_var.set(21)
                self.latereturnfine_var.set("Rs.15")
                self.actualprice_var.set("Rs.397")
                
            elif(x=="Little Women"):
                self.bookid_var.set("582")
                self.bookname_var.set("Little Women")
                self.auther_var.set("Louisa May Alcott")
                
                d1=datetime.datetime.today()
                d2=datetime.timedelta(days=21)
                d3=d1+d2
                self.dateborrowed_var.set(d1)
                self.datedue_var.set(d3)
                self.daysonbook_var.set(21)
                self.latereturnfine_var.set("Rs.15")
                self.actualprice_var.set("Rs.587")
                
            elif(x=="The Sun Also Rises"):
                self.bookid_var.set("539")
                self.bookname_var.set("The Sun Also Rises")
                self.auther_var.set("Ernest Hemingway")
                
                d1=datetime.datetime.today()
                d2=datetime.timedelta(days=21)
                d3=d1+d2
                self.dateborrowed_var.set(d1)
                self.datedue_var.set(d3)
                self.daysonbook_var.set(21)
                self.latereturnfine_var.set("Rs.15")
                self.actualprice_var.set("Rs.117")
                
            elif(x=="The grapes of warth"):
                self.bookid_var.set("289")
                self.bookname_var.set("The grapes of warth")
                self.auther_var.set("John Steinbeck")
                
                d1=datetime.datetime.today()
                d2=datetime.timedelta(days=21)
                d3=d1+d2
                self.dateborrowed_var.set(d1)
                self.datedue_var.set(d3)
                self.daysonbook_var.set(21)
                self.latereturnfine_var.set("Rs.15")
                self.actualprice_var.set("Rs.297")
                
            elif(x=="lolita"):
                self.bookid_var.set("634")
                self.bookname_var.set("lolita")
                self.auther_var.set("Valdimir Nabokov")
                
                d1=datetime.datetime.today()
                d2=datetime.timedelta(days=21)
                d3=d1+d2
                self.dateborrowed_var.set(d1)
                self.datedue_var.set(d3)
                self.daysonbook_var.set(21)
                self.latereturnfine_var.set("Rs.15")
                self.actualprice_var.set("Rs.382")
                
            elif(x=="Catch-22"):
                self.bookid_var.set("537")
                self.bookname_var.set("Catch-22")
                self.auther_var.set("Joseph Heller")
                
                d1=datetime.datetime.today()
                d2=datetime.timedelta(days=21)
                d3=d1+d2
                self.dateborrowed_var.set(d1)
                self.datedue_var.set(d3)
                self.daysonbook_var.set(21)
                self.latereturnfine_var.set("Rs.15")
                self.actualprice_var.set("Rs.926")
                
            elif(x=="Middlemarch"):
                self.bookid_var.set("864")
                self.bookname_var.set("Middlemarch")
                self.auther_var.set("George Eliot")
                
                d1=datetime.datetime.today()
                d2=datetime.timedelta(days=21)
                d3=d1+d2
                self.dateborrowed_var.set(d1)
                self.datedue_var.set(d3)
                self.daysonbook_var.set(21)
                self.latereturnfine_var.set("Rs.15")
                self.actualprice_var.set("Rs.869")
                
            elif(x=="Brave New World"):
                self.bookid_var.set("276")
                self.bookname_var.set("Brave New World")
                self.auther_var.set("Aldous Huxley")
                
                d1=datetime.datetime.today()
                d2=datetime.timedelta(days=21)
                d3=d1+d2
                self.dateborrowed_var.set(d1)
                self.datedue_var.set(d3)
                self.daysonbook_var.set(21)
                self.latereturnfine_var.set("Rs.15")
                self.actualprice_var.set("Rs.263")
                
            elif(x=="Vanity Fair"):
                self.bookid_var.set("876")
                self.bookname_var.set("Vanity Fair")
                self.auther_var.set("William Makepeace Thackeray")
                
                d1=datetime.datetime.today()
                d2=datetime.timedelta(days=21)
                d3=d1+d2
                self.dateborrowed_var.set(d1)
                self.datedue_var.set(d3)
                self.daysonbook_var.set(21)
                self.latereturnfine_var.set("Rs.15")
                self.actualprice_var.set("Rs.275")
                
            elif(x=="Lord of the flies"):
                self.bookid_var.set("275")
                self.bookname_var.set("Lord of the flies")
                self.auther_var.set("Willam Golding")
                
                d1=datetime.datetime.today()
                d2=datetime.timedelta(days=21)
                d3=d1+d2
                self.dateborrowed_var.set(d1)
                self.datedue_var.set(d3)
                self.daysonbook_var.set(21)
                self.latereturnfine_var.set("Rs.15")
                self.actualprice_var.set("Rs.873")
             
            elif(x=="Madame Bovary"):
                self.bookid_var.set("463")
                self.bookname_var.set("Madame Bovary")
                self.auther_var.set("Gustave Flaubert")
                
                d1=datetime.datetime.today()
                d2=datetime.timedelta(days=21)
                d3=d1+d2
                self.dateborrowed_var.set(d1)
                self.datedue_var.set(d3)
                self.daysonbook_var.set(21)
                self.latereturnfine_var.set("Rs.15")
                self.actualprice_var.set("Rs.736")
                
            elif(x=="As I lay Dying"):
                self.bookid_var.set("735")
                self.bookname_var.set("As I lay Dying")
                self.auther_var.set("William Faulker")
                
                d1=datetime.datetime.today()
                d2=datetime.timedelta(days=21)
                d3=d1+d2
                self.dateborrowed_var.set(d1)
                self.datedue_var.set(d3)
                self.daysonbook_var.set(21)
                self.latereturnfine_var.set("Rs.15")
                self.actualprice_var.set("Rs.234")
                
            elif(x=="The good solider"):
                self.bookid_var.set("321")
                self.bookname_var.set("The good solider")
                self.auther_var.set("Ford Madox Ford")
                
                d1=datetime.datetime.today()
                d2=datetime.timedelta(days=21)
                d3=d1+d2
                self.dateborrowed_var.set(d1)
                self.datedue_var.set(d3)
                self.daysonbook_var.set(21)
                self.latereturnfine_var.set("Rs.15")
                self.actualprice_var.set("Rs.456")
                
            elif(x=="Midnight children"):
                self.bookid_var.set("437")
                self.bookname_var.set("Midnight children")
                self.auther_var.set("Salman Rushdie")
                
                d1=datetime.datetime.today()
                d2=datetime.timedelta(days=21)
                d3=d1+d2
                self.dateborrowed_var.set(d1)
                self.datedue_var.set(d3)
                self.daysonbook_var.set(21)
                self.latereturnfine_var.set("Rs.15")
                self.actualprice_var.set("Rs.845")
                  
        
        
        listBox=Listbox(DataFrameRight,font=("arial",12,"bold"),width=20,height=14)
        listBox.bind("<<ListboxSelect>>",SelectBook)
        listBox.grid(row=0,column=0,padx=4)
        listScrollbar.config(command=listBox.yview)
        
        for item in listBooks:
            listBox.insert(END,item)
        
       # ====================================================BUTTONS FRAME=====================================================================   
       
        Framebutton=Frame(self.root,bd=12,relief=RIDGE,padx=20,bg="powder blue")
        Framebutton.place(x=0,y=500,width=1530,height=60) 
        
        btnAddData=Button(Framebutton,command=self.add_data,text="Add data",font=("arial",12,"bold"),width=23,bg="blue",fg="white")
        btnAddData.grid(row=0,column=0)
        
        btnShowData=Button(Framebutton,command=self.showData,text="Show data",font=("arial",12,"bold"),width=23,bg="blue",fg="white")
        btnShowData.grid(row=0,column=1)
        
        btnUpdate=Button(Framebutton,command=self.update,text="Update",font=("arial",12,"bold"),width=23,bg="blue",fg="white")
        btnUpdate.grid(row=0,column=2)
        
        btnDelete=Button(Framebutton,command=self.delete,text="Delete",font=("arial",12,"bold"),width=23,bg="blue",fg="white")
        btnDelete.grid(row=0,column=3)
        
        btnReset=Button(Framebutton,command=self.reset,text="Reset",font=("arial",12,"bold"),width=23,bg="blue",fg="white")
        btnReset.grid(row=0,column=4)
        
        btnExit=Button(Framebutton,command=self.iExit,text="Exit",font=("arial",12,"bold"),width=23,bg="blue",fg="white")
        btnExit.grid(row=0,column=5)
        
        # ====================================================information FRAME=====================================================================   
       
        FrameDetails=Frame(self.root,bd=12,relief=RIDGE,padx=20,bg="powder blue")
        FrameDetails.place(x=0,y=560,width=1530,height=220)  
        
        Table_frame=Frame(FrameDetails,bd=12,relief=RIDGE,padx=20,bg="powder blue")
        Table_frame.place(x=0,y=2,width=1480,height=190)
        
        xscroll=ttk.Scrollbar(Table_frame,orient=HORIZONTAL)
        yscroll=ttk.Scrollbar(Table_frame,orient=VERTICAL)
        
        self.library_table=ttk.Treeview(Table_frame,column=("membertype","rollno","firstname","lastname","branch","yearofgraduation","phoneno","address","bookid",
                                                            "bookname","auther","dateborrowed","datedue","daysonbook","latereturnfine","actualprice"),xscrollcommand=xscroll.set,yscrollcommand=yscroll.set)
        
        xscroll.pack(side=BOTTOM,fill=X)
        yscroll.pack(side=RIGHT,fill=Y)
        
        xscroll.config(command=self.library_table.xview)
        yscroll.config(command=self.library_table.yview)
        
        self.library_table.heading("membertype",text="Member type")
        self.library_table.heading("rollno",text="Roll no")
        self.library_table.heading("firstname",text="First Name")
        self.library_table.heading("lastname",text="Last Name")
        self.library_table.heading("branch",text="Branch")
        self.library_table.heading("yearofgraduation",text="Graduation year")
        self.library_table.heading("phoneno",text="Phone no")
        self.library_table.heading("address",text="Address")
        self.library_table.heading("bookid",text="Book id")
        self.library_table.heading("bookname",text="Book Name")
        self.library_table.heading("auther",text="Author")
        self.library_table.heading("dateborrowed",text="Date of Borrow")
        self.library_table.heading("datedue",text="Date Due")
        self.library_table.heading("daysonbook",text="Days on book")
        self.library_table.heading("latereturnfine",text="Late Return Fine")
        self.library_table.heading("actualprice",text="Actual price")
        
        self.library_table["show"]="headings"
        self.library_table.pack(fill=BOTH,expand=1)
        
        self.library_table.column("membertype",width=100)
        self.library_table.column("rollno",width=100)
        self.library_table.column("firstname",width=100)
        self.library_table.column("lastname",width=100)
        self.library_table.column("branch",width=100)
        self.library_table.column("yearofgraduation",width=100)
        self.library_table.column("phoneno",width=100)
        self.library_table.column("address",width=100)
        self.library_table.column("bookid",width=100)
        self.library_table.column("bookname",width=100)
        self.library_table.column("auther",width=100)
        self.library_table.column("dateborrowed",width=100)
        self.library_table.column("datedue",width=100)
        self.library_table.column("daysonbook",width=100)
        self.library_table.column("latereturnfine",width=100)
        self.library_table.column("actualprice",width=100)
     
     
        self.fetch_data()
        self.library_table.bind("<<ButtonRelease-1>>",self.get_cursor)
   #=====================================================================mysqldataconnect================================================================ 
   #==============================================================add function===========================================================================    
    def add_data(self):
        conn=mysql.connector.connect (
            host="localhost",
            username="root",
            password="root",
            database="lb"
         )    
        cursor=conn.cursor()
        
        insert="""insert into Library values (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
        
        value = (
                                                                                                                     self.member_var.get(),
                                                                                                                     self.rollno_var.get(),
                                                                                                                     self.firstname_var.get(),
                                                                                                                     self.lastname_var.get(),
                                                                                                                     self.branch_var.get(),
                                                                                                                     self.yearofgraduation_var.get(),
                                                                                                                     self.phoneno_var.get(),
                                                                                                                     self.address_var.get(),
                                                                                                                     self.bookid_var.get(),
                                                                                                                     self.bookname_var.get(),
                                                                                                                     self.auther_var.get(),
                                                                                                                     self.dateborrowed_var.get(),
                                                                                                                     self.datedue_var.get(),
                                                                                                                     self.daysonbook_var.get(),
                                                                                                                     self.latereturnfine_var.get(),
                                                                                                                     self.actualprice_var.get()
                                                                                                                   )
        
        cursor.execute(insert,value)
                                                                                                                     
        conn.commit()
        self.fetch_data()
        conn.close()
        
        
        messagebox.showinfo("Success","Member has been inserted successfully")
        
   #==============================================================update function===========================================================================     
    def update(self):
        conn=mysql.connector.connect (
            host="localhost",
            username="root",
            password="root",
            database="lb"
         )    
        cursor=conn.cursor()
        cursor.execute("update library set member=%s,firstname=%s,lastname=%s,branch=%s,yearofgraduation=%s,phoneno=%s,address=%s,bookid=%s,bookname=%s,auther=%s,dateborrowed=%s,datedue=%s,daysonbook=%s,latereturnfine=%s,actualprice=%s,rollno=%s"),(
                                                                                                                     self.member_var.get(),
                                                                                                                     self.firstname_var.get(),
                                                                                                                     self.lastname_var.get(),
                                                                                                                     self.branch_var.get(),
                                                                                                                     self.yearofgraduation_var.get(),
                                                                                                                     self.phoneno_var.get(),
                                                                                                                     self.address_var.get(),
                                                                                                                     self.bookid_var.get(),
                                                                                                                     self.bookname_var.get(),
                                                                                                                     self.auther_var.get(),
                                                                                                                     self.dateborrowed_var.get(),
                                                                                                                     self.datedue_var.get(),
                                                                                                                     self.daysonbook_var.get(),
                                                                                                                     self.latereturnfine_var.get(),
                                                                                                                     self.actualprice_var.get(),
                                                                                                                     self.rollno_var.get()
           )
        
        conn.commit()
        self.fetch_data()
        self.reset()
        conn.close()
        
        messagebox.showinfo("Success","Member has been updated")
        
    #==============================================================fetch function===========================================================================
        
    def fetch_data(self):
        conn=mysql.connector.connect (
            host="localhost",
            username="root",
            password="root",
            database="lb"
         )    
        cursor=conn.cursor()
        cursor.execute("Select* from Library")
        rows=cursor.fetchall()
        
        if len(rows)!=0:
            self.library_table.delete(*self.library_table.get_children())
            for i in rows:
                self.library_table.insert("",END,values=i)
            conn.commit()
        conn.close()
        
    #==============================================================getcursor function===========================================================================   
    def get_cursor(self,event=""):
        cursor_row=self.library_table.focus()
        content=self.library_table.item(cursor_row)
        row=content['values']
        
        self.member_var.set(row[0]),
        self.rollno_var.set(row[1]),
        self.firstname_var.set(row[2]),
        self.lastname_var.set(row[3]),
        self.branch_var.set(row[4]),
        self.yearofgraduation_var.set(row[5]),
        self.phoneno_var.set(row[6]),
        self.address_var.set(row[7]),
        self.bookid_var.set(row[8]),
        self.bookname_var.set(row[9]),
        self.auther_var.set(row[10]),
        self.dateborrowed_var.set(row[11]),
        self.datedue_var.set(row[12]),
        self.daysonbook_var.set(row[13]),
        self.latereturnfine_var.set(row[14]),
        self.actualprice_var.set(row[15])
        
    #==============================================================showdata function===========================================================================  
    def showData(self):
        self.txtBox.insert(END,"Member Type: \t\t"+self.member_var.get()+ "\n")
        self.txtBox.insert(END,"Roll no: \t\t"+self.rollno_var.get()+ "\n")
        self.txtBox.insert(END,"First name: \t\t"+self.firstname_var.get()+ "\n")
        self.txtBox.insert(END,"Last name: \t\t"+self.lastname_var.get()+ "\n")
        self.txtBox.insert(END,"Branch: \t\t"+self.branch_var.get()+ "\n")
        self.txtBox.insert(END,"Gaduation year: \t\t"+self.yearofgraduation_var.get()+ "\n")
        self.txtBox.insert(END,"Phone no: \t\t"+self.phoneno_var.get()+ "\n")
        self.txtBox.insert(END,"Address: \t\t"+self.address_var.get()+ "\n")
        self.txtBox.insert(END,"Book id: \t\t"+self.bookid_var.get()+ "\n")
        self.txtBox.insert(END,"Book name: \t\t"+self.bookname_var.get()+ "\n")
        self.txtBox.insert(END,"Auther: \t\t"+self.auther_var.get()+ "\n")
        self.txtBox.insert(END,"Date of Borrow: \t\t"+self.dateborrowed_var.get()+ "\n")
        self.txtBox.insert(END,"Date due: \t\t"+self.datedue_var.get()+ "\n")
        self.txtBox.insert(END,"Days on Book: \t\t"+self.daysonbook_var.get()+ "\n")
        self.txtBox.insert(END,"Late Return Fine \t\t"+self.latereturnfine_var.get()+ "\n")
        self.txtBox.insert(END,"Actual price \t\t"+self.actualprice_var.get()+ "\n")
        
    #==============================================================reset function===========================================================================    
    def reset(self):
        self.member_var.set(""),
        self.rollno_var.set(""),
        self.firstname_var.set(""),
        self.lastname_var.set(""),
        self.branch_var.set(""),
        self.yearofgraduation_var.set(""),
        self.phoneno_var.set(""),
        self.address_var.set(""),
        self.bookid_var.set(""),
        self.bookname_var.set(""),
        self.auther_var.set(""),
        self.dateborrowed_var.set(""),
        self.datedue_var.set(""),
        self.daysonbook_var.set(""),
        self.latereturnfine_var.set(""),
        self.actualprice_var.set("")
        self.txtBox.delete("1.0",END)
        
    #==============================================================exit function===========================================================================   
    def iExit(self):
        iExit=tkinter.messagebox.askyesno("Library management system","Do you want to exit")
        if iExit>0:
            self.root.destroy()
            return
    
    
    #==============================================================delete function===========================================================================    
    def delete(self):
        if self.rollno_var.get()==" ":
            messagebox.showerror("Error","First Selet the Member")
        else:
            conn=mysql.connector.connect (
            host="localhost",
            username="root",
            password="root",
            database="lb"
         )    
        cursor=conn.cursor()
        query="delete from library where rollno=%s"
        value=(self.rollno_var.get())
        cursor.execute(query,value)
        
        conn.commit()
        self.fetch_data()
        self.reset()
        conn.close()
        
        messagebox.showinfo("Success","Member ha been deleted")
                
#==================================================================mainfunction================================================================
if __name__=="__main__":
    root=Tk()
    obj=libraryManagementSystem(root) 
    root.mainloop()
    